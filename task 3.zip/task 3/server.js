const express = require('express')
const app = express()
app.get("/app", (req, res) => {
    res.json({ "users": ["nikki", "lahari", "komali", "devi", "vanitha", "suma", "deepu", "durga", "rekha"] })
})
app.listen(5000, () => { console.log("server started on port 5000") })